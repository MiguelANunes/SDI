Equipe: Miguel e Thiago B.
